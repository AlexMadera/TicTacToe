﻿namespace TicTacToe
{
    partial class TicTacToe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPlayer1Name = new System.Windows.Forms.Label();
            this.lblPlayer2Name = new System.Windows.Forms.Label();
            this.grpbox = new System.Windows.Forms.GroupBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panelTicTacToe = new System.Windows.Forms.Panel();
            this.btnTTT1 = new System.Windows.Forms.Button();
            this.btnTTT2 = new System.Windows.Forms.Button();
            this.btnTTT3 = new System.Windows.Forms.Button();
            this.btnTTT4 = new System.Windows.Forms.Button();
            this.btnTTT5 = new System.Windows.Forms.Button();
            this.btnTTT6 = new System.Windows.Forms.Button();
            this.btnTTT7 = new System.Windows.Forms.Button();
            this.btnTTT8 = new System.Windows.Forms.Button();
            this.btnTTT9 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnnewMatch = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblPlayer1Score = new System.Windows.Forms.Label();
            this.lblPlayer2Score = new System.Windows.Forms.Label();
            this.txtboxPlayer1Score = new System.Windows.Forms.TextBox();
            this.txtboxPlayer2Score = new System.Windows.Forms.TextBox();
            this.grpbox.SuspendLayout();
            this.panelTicTacToe.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPlayer1Name
            // 
            this.lblPlayer1Name.AutoSize = true;
            this.lblPlayer1Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayer1Name.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblPlayer1Name.Location = new System.Drawing.Point(6, 29);
            this.lblPlayer1Name.Name = "lblPlayer1Name";
            this.lblPlayer1Name.Size = new System.Drawing.Size(146, 20);
            this.lblPlayer1Name.TabIndex = 0;
            this.lblPlayer1Name.Text = "Player one name is:";
            // 
            // lblPlayer2Name
            // 
            this.lblPlayer2Name.AutoSize = true;
            this.lblPlayer2Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayer2Name.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblPlayer2Name.Location = new System.Drawing.Point(8, 59);
            this.lblPlayer2Name.Name = "lblPlayer2Name";
            this.lblPlayer2Name.Size = new System.Drawing.Size(144, 20);
            this.lblPlayer2Name.TabIndex = 1;
            this.lblPlayer2Name.Text = "Player two name is:";
            // 
            // grpbox
            // 
            this.grpbox.BackColor = System.Drawing.Color.Azure;
            this.grpbox.Controls.Add(this.panel2);
            this.grpbox.Controls.Add(this.panel1);
            this.grpbox.Controls.Add(this.lblPlayer1Name);
            this.grpbox.Controls.Add(this.lblPlayer2Name);
            this.grpbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbox.ForeColor = System.Drawing.Color.Blue;
            this.grpbox.Location = new System.Drawing.Point(-3, -13);
            this.grpbox.Name = "grpbox";
            this.grpbox.Size = new System.Drawing.Size(275, 478);
            this.grpbox.TabIndex = 2;
            this.grpbox.TabStop = false;
            // 
            // panelTicTacToe
            // 
            this.panelTicTacToe.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelTicTacToe.Controls.Add(this.btnTTT9);
            this.panelTicTacToe.Controls.Add(this.btnTTT6);
            this.panelTicTacToe.Controls.Add(this.btnTTT3);
            this.panelTicTacToe.Controls.Add(this.btnTTT8);
            this.panelTicTacToe.Controls.Add(this.btnTTT5);
            this.panelTicTacToe.Controls.Add(this.btnTTT2);
            this.panelTicTacToe.Controls.Add(this.btnTTT7);
            this.panelTicTacToe.Controls.Add(this.btnTTT4);
            this.panelTicTacToe.Controls.Add(this.btnTTT1);
            this.panelTicTacToe.Location = new System.Drawing.Point(278, 2);
            this.panelTicTacToe.Name = "panelTicTacToe";
            this.panelTicTacToe.Size = new System.Drawing.Size(519, 447);
            this.panelTicTacToe.TabIndex = 3;
            // 
            // btnTTT1
            // 
            this.btnTTT1.BackColor = System.Drawing.Color.Azure;
            this.btnTTT1.Font = new System.Drawing.Font("Microsoft Sans Serif", 95F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTTT1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnTTT1.Location = new System.Drawing.Point(0, 0);
            this.btnTTT1.Name = "btnTTT1";
            this.btnTTT1.Size = new System.Drawing.Size(169, 143);
            this.btnTTT1.TabIndex = 0;
            this.btnTTT1.UseVisualStyleBackColor = false;
            this.btnTTT1.Click += new System.EventHandler(this.btnTTT1_Click);
            // 
            // btnTTT2
            // 
            this.btnTTT2.BackColor = System.Drawing.Color.Azure;
            this.btnTTT2.Font = new System.Drawing.Font("Microsoft Sans Serif", 95F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTTT2.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnTTT2.Location = new System.Drawing.Point(175, 0);
            this.btnTTT2.Name = "btnTTT2";
            this.btnTTT2.Size = new System.Drawing.Size(169, 143);
            this.btnTTT2.TabIndex = 0;
            this.btnTTT2.UseVisualStyleBackColor = false;
            this.btnTTT2.Click += new System.EventHandler(this.btnTTT2_Click);
            // 
            // btnTTT3
            // 
            this.btnTTT3.BackColor = System.Drawing.Color.Azure;
            this.btnTTT3.Font = new System.Drawing.Font("Microsoft Sans Serif", 95F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTTT3.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnTTT3.Location = new System.Drawing.Point(350, 0);
            this.btnTTT3.Name = "btnTTT3";
            this.btnTTT3.Size = new System.Drawing.Size(169, 143);
            this.btnTTT3.TabIndex = 0;
            this.btnTTT3.UseVisualStyleBackColor = false;
            this.btnTTT3.Click += new System.EventHandler(this.btnTTT3_Click);
            // 
            // btnTTT4
            // 
            this.btnTTT4.BackColor = System.Drawing.Color.Azure;
            this.btnTTT4.Font = new System.Drawing.Font("Microsoft Sans Serif", 95F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTTT4.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnTTT4.Location = new System.Drawing.Point(0, 149);
            this.btnTTT4.Name = "btnTTT4";
            this.btnTTT4.Size = new System.Drawing.Size(169, 143);
            this.btnTTT4.TabIndex = 0;
            this.btnTTT4.UseVisualStyleBackColor = false;
            this.btnTTT4.Click += new System.EventHandler(this.btnTTT4_Click);
            // 
            // btnTTT5
            // 
            this.btnTTT5.BackColor = System.Drawing.Color.Azure;
            this.btnTTT5.Font = new System.Drawing.Font("Microsoft Sans Serif", 95F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTTT5.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnTTT5.Location = new System.Drawing.Point(175, 149);
            this.btnTTT5.Name = "btnTTT5";
            this.btnTTT5.Size = new System.Drawing.Size(169, 143);
            this.btnTTT5.TabIndex = 0;
            this.btnTTT5.UseVisualStyleBackColor = false;
            this.btnTTT5.Click += new System.EventHandler(this.btnTTT5_Click);
            // 
            // btnTTT6
            // 
            this.btnTTT6.BackColor = System.Drawing.Color.Azure;
            this.btnTTT6.Font = new System.Drawing.Font("Microsoft Sans Serif", 95F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTTT6.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnTTT6.Location = new System.Drawing.Point(350, 149);
            this.btnTTT6.Name = "btnTTT6";
            this.btnTTT6.Size = new System.Drawing.Size(169, 143);
            this.btnTTT6.TabIndex = 0;
            this.btnTTT6.UseVisualStyleBackColor = false;
            this.btnTTT6.Click += new System.EventHandler(this.btnTTT6_Click);
            // 
            // btnTTT7
            // 
            this.btnTTT7.BackColor = System.Drawing.Color.Azure;
            this.btnTTT7.Font = new System.Drawing.Font("Microsoft Sans Serif", 95F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTTT7.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnTTT7.Location = new System.Drawing.Point(0, 298);
            this.btnTTT7.Name = "btnTTT7";
            this.btnTTT7.Size = new System.Drawing.Size(169, 143);
            this.btnTTT7.TabIndex = 0;
            this.btnTTT7.UseVisualStyleBackColor = false;
            this.btnTTT7.Click += new System.EventHandler(this.btnTTT7_Click);
            // 
            // btnTTT8
            // 
            this.btnTTT8.BackColor = System.Drawing.Color.Azure;
            this.btnTTT8.Font = new System.Drawing.Font("Microsoft Sans Serif", 95F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTTT8.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnTTT8.Location = new System.Drawing.Point(175, 298);
            this.btnTTT8.Name = "btnTTT8";
            this.btnTTT8.Size = new System.Drawing.Size(169, 143);
            this.btnTTT8.TabIndex = 0;
            this.btnTTT8.UseVisualStyleBackColor = false;
            this.btnTTT8.Click += new System.EventHandler(this.btnTTT8_Click);
            // 
            // btnTTT9
            // 
            this.btnTTT9.BackColor = System.Drawing.Color.Azure;
            this.btnTTT9.Font = new System.Drawing.Font("Microsoft Sans Serif", 95F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTTT9.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnTTT9.Location = new System.Drawing.Point(350, 298);
            this.btnTTT9.Name = "btnTTT9";
            this.btnTTT9.Size = new System.Drawing.Size(169, 143);
            this.btnTTT9.TabIndex = 0;
            this.btnTTT9.UseVisualStyleBackColor = false;
            this.btnTTT9.Click += new System.EventHandler(this.btnTTT9_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightCyan;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.btnExit);
            this.panel1.Controls.Add(this.btnReset);
            this.panel1.Controls.Add(this.btnnewMatch);
            this.panel1.Location = new System.Drawing.Point(6, 285);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(263, 177);
            this.panel1.TabIndex = 2;
            // 
            // btnnewMatch
            // 
            this.btnnewMatch.BackColor = System.Drawing.Color.LightCyan;
            this.btnnewMatch.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnewMatch.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnnewMatch.Location = new System.Drawing.Point(53, 3);
            this.btnnewMatch.Name = "btnnewMatch";
            this.btnnewMatch.Size = new System.Drawing.Size(160, 45);
            this.btnnewMatch.TabIndex = 0;
            this.btnnewMatch.Text = "NEW MATCH";
            this.btnnewMatch.UseVisualStyleBackColor = false;
            this.btnnewMatch.Click += new System.EventHandler(this.btnnewMatch_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.LightCyan;
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnReset.Location = new System.Drawing.Point(53, 64);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(160, 45);
            this.btnReset.TabIndex = 0;
            this.btnReset.Text = "RESET";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.LightCyan;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnExit.Location = new System.Drawing.Point(53, 126);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(160, 45);
            this.btnExit.TabIndex = 0;
            this.btnExit.Text = "EXIT";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.txtboxPlayer2Score);
            this.panel2.Controls.Add(this.txtboxPlayer1Score);
            this.panel2.Controls.Add(this.lblPlayer2Score);
            this.panel2.Controls.Add(this.lblPlayer1Score);
            this.panel2.ForeColor = System.Drawing.Color.MidnightBlue;
            this.panel2.Location = new System.Drawing.Point(6, 166);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(263, 100);
            this.panel2.TabIndex = 4;
            // 
            // lblPlayer1Score
            // 
            this.lblPlayer1Score.AutoSize = true;
            this.lblPlayer1Score.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayer1Score.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblPlayer1Score.Location = new System.Drawing.Point(7, 10);
            this.lblPlayer1Score.Name = "lblPlayer1Score";
            this.lblPlayer1Score.Size = new System.Drawing.Size(108, 20);
            this.lblPlayer1Score.TabIndex = 0;
            this.lblPlayer1Score.Text = "Player 1 score";
            // 
            // lblPlayer2Score
            // 
            this.lblPlayer2Score.AutoSize = true;
            this.lblPlayer2Score.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayer2Score.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblPlayer2Score.Location = new System.Drawing.Point(7, 55);
            this.lblPlayer2Score.Name = "lblPlayer2Score";
            this.lblPlayer2Score.Size = new System.Drawing.Size(108, 20);
            this.lblPlayer2Score.TabIndex = 0;
            this.lblPlayer2Score.Text = "Player 2 score";
            // 
            // txtboxPlayer1Score
            // 
            this.txtboxPlayer1Score.BackColor = System.Drawing.Color.Azure;
            this.txtboxPlayer1Score.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxPlayer1Score.ForeColor = System.Drawing.Color.MidnightBlue;
            this.txtboxPlayer1Score.Location = new System.Drawing.Point(173, 3);
            this.txtboxPlayer1Score.Name = "txtboxPlayer1Score";
            this.txtboxPlayer1Score.Size = new System.Drawing.Size(40, 38);
            this.txtboxPlayer1Score.TabIndex = 1;
            this.txtboxPlayer1Score.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtboxPlayer2Score
            // 
            this.txtboxPlayer2Score.BackColor = System.Drawing.Color.Azure;
            this.txtboxPlayer2Score.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxPlayer2Score.ForeColor = System.Drawing.Color.MidnightBlue;
            this.txtboxPlayer2Score.Location = new System.Drawing.Point(173, 47);
            this.txtboxPlayer2Score.Name = "txtboxPlayer2Score";
            this.txtboxPlayer2Score.Size = new System.Drawing.Size(40, 38);
            this.txtboxPlayer2Score.TabIndex = 1;
            this.txtboxPlayer2Score.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TicTacToe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelTicTacToe);
            this.Controls.Add(this.grpbox);
            this.Name = "TicTacToe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "TicTacToe";
            this.Load += new System.EventHandler(this.TicTacToe_Load);
            this.grpbox.ResumeLayout(false);
            this.grpbox.PerformLayout();
            this.panelTicTacToe.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblPlayer1Name;
        private System.Windows.Forms.Label lblPlayer2Name;
        private System.Windows.Forms.GroupBox grpbox;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Panel panelTicTacToe;
        private System.Windows.Forms.Button btnTTT1;
        private System.Windows.Forms.Button btnTTT9;
        private System.Windows.Forms.Button btnTTT6;
        private System.Windows.Forms.Button btnTTT3;
        private System.Windows.Forms.Button btnTTT8;
        private System.Windows.Forms.Button btnTTT5;
        private System.Windows.Forms.Button btnTTT2;
        private System.Windows.Forms.Button btnTTT7;
        private System.Windows.Forms.Button btnTTT4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnnewMatch;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtboxPlayer2Score;
        private System.Windows.Forms.TextBox txtboxPlayer1Score;
        private System.Windows.Forms.Label lblPlayer2Score;
        private System.Windows.Forms.Label lblPlayer1Score;
    }
}