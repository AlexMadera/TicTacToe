﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class TicTacToe : Form
    {
        
        Boolean player1_turn;
        Boolean playerWon = false;
        string playerX_name;
        string playerO_name;
        int playerX_score;
        int playerO_score;

        public TicTacToe()
        {
            InitializeComponent();
        }
     
        public TicTacToe(string Playername1, string Playername2)
        {
            InitializeComponent();
            randomizedWhoStart();
            playerX_name = Playername1;
            playerO_name = Playername2;
            lblPlayer1Score.Text = playerX_name +"'s score";
            lblPlayer2Score.Text = playerO_name + "'s score";
            txtboxPlayer1Score.Enabled = false;
            txtboxPlayer2Score.Enabled = false;
            txtboxPlayer1Score.Text = "0";
            txtboxPlayer2Score.Text = "0";
            lblPlayer1Name.Text = "Player one name is: " + Playername1 + " (X)";
            lblPlayer2Name.Text = "Player two name is: " + Playername2 + " (O)";

        }


        private void TicTacToe_Load(object sender, EventArgs e)
        {

        }

        
        private void CheckifXWon()
        {
            if (btnTTT1.Text=="X" && btnTTT2.Text == "X" && btnTTT3.Text == "X")
            {
                MessageBox.Show("The winner is player " + playerX_name,"",MessageBoxButtons.OK,MessageBoxIcon.Information);
                playerWon = true;
                AddScoreToX();
                False_enabled();
            }

            if (btnTTT4.Text == "X" && btnTTT5.Text == "X" && btnTTT6.Text == "X")
            {
                MessageBox.Show("The winner is player " + playerX_name, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                playerWon = true;
                AddScoreToX();
                False_enabled();
            }

            if (btnTTT7.Text == "X" && btnTTT8.Text == "X" && btnTTT9.Text == "X")
            {

                MessageBox.Show("The winner is player " + playerX_name, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                playerWon = true;
                AddScoreToX();
                False_enabled();
            }

            if (btnTTT1.Text == "X" && btnTTT4.Text == "X" && btnTTT7.Text == "X")
            {

                MessageBox.Show("The winner is player " + playerX_name, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                playerWon = true;
                AddScoreToX();
                False_enabled();
            }

            if (btnTTT2.Text == "X" && btnTTT5.Text == "X" && btnTTT8.Text == "X")
            {

                MessageBox.Show("The winner is player " + playerX_name, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                playerWon = true;
                AddScoreToX();
                False_enabled();
            }

            if (btnTTT3.Text == "X" && btnTTT6.Text == "X" && btnTTT9.Text == "X")
            {


                MessageBox.Show("The winner is player " + playerX_name, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                playerWon = true;
                AddScoreToX();
                False_enabled();
            }

            if (btnTTT1.Text == "X" && btnTTT5.Text == "X" && btnTTT9.Text == "X")
            {

                MessageBox.Show("The winner is player " + playerX_name, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                playerWon = true;
                AddScoreToX();
                False_enabled();
            }

            if (btnTTT3.Text == "X" && btnTTT5.Text == "X" && btnTTT7.Text == "X")
            {

                MessageBox.Show("The winner is player " + playerX_name, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                playerWon = true;
                AddScoreToX();
                False_enabled();
            }
        }

        private void CheckifOWon()
        {
            if (btnTTT1.Text == "O" && btnTTT2.Text == "O" && btnTTT3.Text == "O")
            {
                
                MessageBox.Show("The winner is player " + playerO_name, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                playerWon = true;
                AddScoreToO();
                False_enabled();
            }

            if (btnTTT4.Text == "O" && btnTTT5.Text == "O" && btnTTT6.Text == "O")
            {

                MessageBox.Show("The winner is player " + playerO_name, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                playerWon = true;
                AddScoreToO();
                False_enabled();
            }

            if (btnTTT7.Text == "O" && btnTTT8.Text == "O" && btnTTT9.Text == "O")
            {
                MessageBox.Show("The winner is player " + playerO_name, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                playerWon = true;
                AddScoreToO();
                False_enabled();
            }

            if (btnTTT1.Text == "O" && btnTTT4.Text == "O" && btnTTT7.Text == "O")
            {
                MessageBox.Show("The winner is player " + playerO_name, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                playerWon = true;
                AddScoreToO();
                False_enabled();
            }

            if (btnTTT2.Text == "O" && btnTTT5.Text == "O" && btnTTT8.Text == "O")
            {

                MessageBox.Show("The winner is player " + playerO_name, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                playerWon = true;
                AddScoreToO();
                False_enabled();
            }

            if (btnTTT3.Text == "O" && btnTTT6.Text == "O" && btnTTT9.Text == "O")
            {
                MessageBox.Show("The winner is player " + playerO_name, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                playerWon = true;
                AddScoreToO();
                False_enabled();
            }

            if (btnTTT1.Text == "O" && btnTTT5.Text == "O" && btnTTT9.Text == "O")
            {
                MessageBox.Show("The winner is player " + playerO_name, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                playerWon = true;
                AddScoreToO();
                False_enabled();
            }

            if (btnTTT3.Text == "O" && btnTTT5.Text == "O" && btnTTT7.Text == "O")
            {

                MessageBox.Show("The winner is player " + playerO_name, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                playerWon = true;
                AddScoreToO();
                False_enabled();
            }
        }

        private void btnTTT1_Click(object sender, EventArgs e)
        {
            if (player1_turn == true)
            {
                btnTTT1.Text = "X";
                player1_turn = false;
            }
            else
            {
                btnTTT1.Text = "O";
                player1_turn = true;
            }
            CheckifXWon();
            CheckifOWon();
            btnTTT1.Enabled = false;
            Draw();
        }

        private void btnTTT2_Click(object sender, EventArgs e)
        {
            if (player1_turn == true)
            {
                btnTTT2.Text = "X";
                player1_turn = false;
            }
            else
            {
                btnTTT2.Text = "O";
                player1_turn = true;
            }
            CheckifXWon();
            CheckifOWon();
            btnTTT2.Enabled = false;
            Draw();
        }

        private void btnTTT3_Click(object sender, EventArgs e)
        {
            if (player1_turn == true)
            {
                btnTTT3.Text = "X";
                player1_turn = false;
            }
            else
            {
                btnTTT3.Text = "O";
                player1_turn = true;
            }
            CheckifXWon();
            CheckifOWon();
            btnTTT3.Enabled = false;
            Draw();
        }

        private void btnTTT4_Click(object sender, EventArgs e)
        {
            if (player1_turn == true)
            {
                btnTTT4.Text = "X";
                player1_turn = false;
            }
            else
            {
                btnTTT4.Text = "O";
                player1_turn = true;
            }
            CheckifXWon();
            CheckifOWon();
            btnTTT4.Enabled = false;
            Draw();
        }

        private void btnTTT5_Click(object sender, EventArgs e)
        {
            if (player1_turn == true)
            {
                btnTTT5.Text = "X";
                player1_turn = false;
            }
            else
            {
                btnTTT5.Text = "O";
                player1_turn = true;
            }
            CheckifXWon();
            CheckifOWon();
            btnTTT5.Enabled = false;
            Draw();
        }

        private void btnTTT6_Click(object sender, EventArgs e)
        {
            if (player1_turn == true)
            {
                btnTTT6.Text = "X";
                player1_turn = false;
            }
            else
            {
                btnTTT6.Text = "O";
                player1_turn = true;
            }
            CheckifXWon();
            CheckifOWon();
            btnTTT6.Enabled = false;
            Draw();
        }

        private void btnTTT7_Click(object sender, EventArgs e)
        {
            if (player1_turn == true)
            {
                btnTTT7.Text = "X";
                player1_turn = false;
            }
            else
            {
                btnTTT7.Text = "O";
                player1_turn = true;
            }
            CheckifXWon();
            CheckifOWon();
            btnTTT7.Enabled = false;
            Draw();
        }

        private void btnTTT8_Click(object sender, EventArgs e)
        {
            if (player1_turn == true)
            {
                btnTTT8.Text = "X";
                player1_turn = false;
            }
            else
            {
                btnTTT8.Text = "O";
                player1_turn = true;
            }
            CheckifXWon();
            CheckifOWon();
            btnTTT8.Enabled = false;
            Draw();
        }

        private void btnTTT9_Click(object sender, EventArgs e)
        {
            if (player1_turn == true)
            {
                btnTTT9.Text = "X";
                player1_turn = false;
            }
            else
            {
                btnTTT9.Text = "O";
                player1_turn = true;
            }
            CheckifXWon();
            CheckifOWon();
            btnTTT9.Enabled = false;
            Draw();
        }
        private void randomizedWhoStart()
        {
            var rand = new Random();
            int i = rand.Next(0, 2);
            if (i == 1) { 
                player1_turn = true;}
            else
                player1_turn = false;
        }
        private void False_enabled()
        {
            btnTTT1.Enabled = false;
            btnTTT2.Enabled = false;
            btnTTT3.Enabled = false;
            btnTTT4.Enabled = false;
            btnTTT5.Enabled = false;
            btnTTT6.Enabled = false;
            btnTTT7.Enabled = false;
            btnTTT8.Enabled = false;
            btnTTT9.Enabled = false;

        }
        private void true_enabled()
        {
            btnTTT1.Enabled = true;
            btnTTT2.Enabled = true;
            btnTTT3.Enabled = true;
            btnTTT4.Enabled = true;
            btnTTT5.Enabled = true;
            btnTTT6.Enabled = true;
            btnTTT7.Enabled = true;
            btnTTT8.Enabled = true;
            btnTTT9.Enabled = true;
        }
        private void clear_buttonTexts()
        {
            btnTTT1.Text = "";
            btnTTT2.Text = "";
            btnTTT3.Text = "";
            btnTTT4.Text = "";
            btnTTT5.Text = "";
            btnTTT6.Text = "";
            btnTTT7.Text = "";
            btnTTT8.Text = "";
            btnTTT9.Text = "";
        }
        private void AddScoreToX()
        {
            playerX_score = int.Parse(txtboxPlayer1Score.Text);
            playerX_score += 1;
            txtboxPlayer1Score.Text = Convert.ToString(playerX_score);
        }
        private void AddScoreToO()

        {
            playerO_score = int.Parse(txtboxPlayer2Score.Text);
            playerO_score += 1;
            txtboxPlayer2Score.Text = Convert.ToString(playerO_score);
        }
        private void Draw()
        {
            if (btnTTT1.Enabled==false && btnTTT2.Enabled == false && btnTTT3.Enabled == false && btnTTT4.Enabled == false
                && btnTTT5.Enabled == false && btnTTT6.Enabled == false && btnTTT7.Enabled == false
                && btnTTT8.Enabled == false && btnTTT9.Enabled == false)
                {
                if (playerWon == false)
                {
                    MessageBox.Show("THIS IS A DRAW", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
               
            }
        }
        private void btnnewMatch_Click(object sender, EventArgs e)
        {
            try
            {
                true_enabled();
                clear_buttonTexts();
                txtboxPlayer1Score.Text = "0";
                txtboxPlayer2Score.Text = "0";
                playerWon = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                true_enabled();
                clear_buttonTexts();
                playerWon = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult sureEXIT;
                sureEXIT = MessageBox.Show("Are you sure you want to exit?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (sureEXIT == DialogResult.Yes)
                {
                    Application.Exit();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,"",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
        }
    }
}
